class Test:
    def __init__(self) -> None:
        pass
    def show(self):
        print("Ich bin ein Berliner")
